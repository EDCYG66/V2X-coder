import os
import time

print("1. 正在配置环境路径...")
os.environ['XLA_FLAGS'] = '--xla_gpu_cuda_data_dir=/environment/miniconda3/envs/tf212'

import tensorflow as tf

def main():
    print("--------------------------------------------------")
    print("🚀 开始 TensorFlow 环境测试")
    print("--------------------------------------------------")

    # 检查 GPU
    print("\n2. 正在检查物理设备 (GPU)...")
    gpus = tf.config.list_physical_devices('GPU')
    if gpus:
        print(f"✅ 成功! 检测到 {len(gpus)} 个 GPU:")
        for gpu in gpus:
            print(f"   - {gpu}")
    else:
        print("⚠️ 警告: 未检测到 GPU")

    # 测试 XLA
    print("\n3. 正在测试 XLA 编译 (验证 libdevice 是否修复)...")
    
    @tf.function(jit_compile=True)
    def simple_xla_calc(x, y):
        return tf.matmul(x, y)

    try:
        a = tf.random.normal([1000, 1000])
        b = tf.random.normal([1000, 1000])
        print("   正在进行矩阵乘法运算...")
        start_time = time.time()
        c = simple_xla_calc(a, b)
        print(f"✅ 运算成功! 耗时: {time.time() - start_time:.4f} 秒")
    except Exception as e:
        print(f"\n❌ XLA 测试失败! 错误: {e}")

    print("\n--------------------------------------------------")
    print("🎉 恭喜! 所有测试通过!")

if __name__ == "__main__":
    main()
