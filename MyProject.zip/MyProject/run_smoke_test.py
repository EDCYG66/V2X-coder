import os
import time

# ==============================================================================
# 1. 配置环境 (解决 libdevice 报错)
# ==============================================================================
# 必须先配置这个，否则主程序一起动就会崩
os.environ['XLA_FLAGS'] = '--xla_gpu_cuda_data_dir=/environment/miniconda3/envs/tf212'
# 过滤掉干扰视线的 TensorFlow 调试信息
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

def main():
    print("=" * 60)
    print(f"[{time.strftime('%H:%M:%S')}] 🚀 开始快速跑通测试 (Smoke Test)...")
    print("目标：使用极少步数和车辆，验证代码流程是否能在 GPU 上跑通")
    print("=" * 60)

    # ==========================================================================
    # 2. 定义测试参数 (关键！)
    # ==========================================================================
    # 这里我们把步数设得非常小，旨在几分钟内跑完流程
    # 请根据你 run_compare_gnn_plus.py 实际的参数名进行微调
    
    cmd_args = [
        "python run_compare_gnn_plus.py",
        
        # --- 关键参数：减少训练量 ---
        "--train-steps 50",      # 只训练 50 步 (原定可能是几万步)
        "--test-every 50",       # 每 50 步测试一次 (确保能触发一次测试逻辑)
        "--test-sample 2",       # 测试时只采样 2 次 (减少测试等待时间)
        
        # --- 关键参数：减少环境复杂度 ---
        # 假设 --veh-list 接受空格分隔或特定格式，这里只测一种密度
        "--veh-list 50",         # 只测 50 辆车的情况 (或根据你代码格式写 "[50]")
        
        # --- 其他可能需要的参数 ---
        # 如果有 --gnn-type，建议显式指定一个最复杂的模型(如 gat)来测，因为FC通常不出错
        "--gnn-type gat",
        "--warmup-steps 20"
    ]
    
    # 拼接命令
    full_command = " ".join(cmd_args)
    
    print("\n执行测试命令:")
    print(f"👉 {full_command}\n")
    print("-" * 60)

    # ==========================================================================
    # 3. 执行测试
    # ==========================================================================
    start_time = time.time()
    
    # 调用系统命令执行
    exit_code = os.system(full_command)
    
    duration = time.time() - start_time
    
    print("\n" + "=" * 60)
    if exit_code == 0:
        print(f"✅ 测试成功！代码跑通了！")
        print(f"⏱️ 耗时: {duration:.2f} 秒")
        print("💡 提示：现在你可以放心地去跑大步数训练了。")
    else:
        print(f"❌ 测试失败！主程序返回错误码: {exit_code}")
        print("请向上翻阅日志查看具体的 Python 报错信息。")
    print("=" * 60)

if __name__ == "__main__":
    main()