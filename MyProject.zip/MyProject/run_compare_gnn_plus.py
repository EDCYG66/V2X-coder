#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Compare GATv2 vs GraphSAGE vs FC with flat output.
"""
import os

# --- 关键：确保 CUDA 路径和 XLA 标志 ---
os.environ['XLA_FLAGS'] = '--xla_gpu_cuda_data_dir=/environment/miniconda3/envs/tf212'

import argparse
import json
import time
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import tensorflow as tf # 确保导入 tf

# --- 新增：启动前显卡自检 ---
print("="*40)
print("[GPU Check]")
gpus = tf.config.list_physical_devices('GPU')
if len(gpus) > 0:
    print(f"✅ Found {len(gpus)} GPU(s): {gpus}")
    try:
        # 尝试显式设置显存增长，防止TF一次性占满导致假死
        for gpu in gpus:
            tf.config.experimental.set_memory_growth(gpu, True)
        print("✅ Memory growth set to True")
    except RuntimeError as e:
        print(f"⚠️ Memory growth setting failed: {e}")
else:
    print("❌ NO GPU FOUND! Check CUDA/Driver.")
print("="*40)

import matplotlib.pyplot as plt

# 假设这些模块在您的项目中存在
from highway_environment import HighwayTopoEnv
from agent import Agent
from gnn_factory import build_gnn


# ================= 工具函数 =================

def compute_entropy(prob: np.ndarray) -> float:
    prob = np.asarray(prob, dtype=np.float64)
    s = prob.sum()
    if s <= 0:
        return 0.0
    p = prob / s
    p = p[p > 0]
    return float(-np.sum(p * np.log(p)))


def compute_gini(counts: np.ndarray) -> float:
    counts = np.asarray(counts, dtype=np.float64)
    if counts.size == 0:
        return 0.0
    s = counts.sum()
    if s <= 0:
        return 0.0
    diffs = np.abs(counts[:, None] - counts[None, :])
    return float(diffs.sum() / (2 * counts.size * s))


def compute_convergence_step(steps: List[int], values: List[float], ratio: float = 0.9) -> int:
    if not steps or not values:
        return -1
    final_v = values[-1]
    thr = ratio * final_v
    for s, v in zip(steps, values):
        if v >= thr:
            return int(s)
    return int(steps[-1])


def ensure_env_difficulty(env: HighwayTopoEnv, demand_amount: float, v2v_limit: float):
    env.demand_amount = float(demand_amount)
    env.demand = env.demand_amount * np.ones((env.n_Veh, 3))
    env.V2V_limit = float(v2v_limit)
    env.individual_time_limit = env.V2V_limit * np.ones((env.n_Veh, 3))
    if hasattr(env, "activate_links"):
        env.activate_links[:] = False


def parse_list_int(s: str) -> List[int]:
    if not s:
        return []
    return [int(x.strip()) for x in s.split(",") if x.strip()]


def parse_list_int_strict(s: str) -> List[int]:
    try:
        return parse_list_int(s)
    except Exception:
        return []


# ================ 带统计的 Agent ================

class InstrumentedAgent(Agent):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # === 修复: 初始化 step 防止 warmup 报错 ===
        self.step = 0
        
        self.rb_usage_counts = np.zeros(self.RB_number, dtype=np.int64)
        self.full_decision_time_acc = []
        self.gnn_only_time_acc = []
        self.v2i_curve_steps = []
        self.v2i_curve_vals = []
        self.v2v_curve_vals = []
        self.last_timeseries = None

    def _collect_power_and_rb(self, i: int, j: int, s_old_raw: np.ndarray, action: int):
        rb = action % self.RB_number
        pw = action // self.RB_number
        self.action_all_with_power_training[i, j, 0] = rb
        self.action_all_with_power_training[i, j, 1] = pw
        
        # 记录日志
        if self.power_log_stride and (self.step % self.power_log_stride == 0):
            time_left_s = float(s_old_raw[-1]) * float(self.env.V2V_limit)
            self.power_log.append((time_left_s, pw))
            if len(self.power_log) > self.power_log_max:
                self.power_log = self.power_log[-self.power_log_max:]
        if 0 <= rb < self.RB_number:
            self.rb_usage_counts[rb] += 1

    # === 关键修复：重写 warmup 以支持 FCNet 特征拼接 ===
    def warmup(self):
        print(f"Start warmup ({self.warmup_steps} steps)...")
        # 强制填充 memory
        for _ in range(self.warmup_steps):
            # 1. 刷新节点特征 (60维)
            for i in range(len(self.env.vehicles)):
                for j in range(3):
                    s = self.get_state([i, j])
                    self.G.features[3 * i + j, :] = s[:60]

            # 2. 前向传播获取 embedding (32维)
            if hasattr(self.G, "_forward_all"):
                # TensorFlow / FCNet
                emb_all_t = self.G._forward_all(training=False)
                emb_all = emb_all_t.numpy() if hasattr(emb_all_t, "numpy") else np.asarray(emb_all_t)
            else:
                # PyTorch / GAT / GraphSAGE
                N = 3 * len(self.env.vehicles)
                emb_all = self.G.use_GraphSAGE(self.channel_reward, 0, list(range(N)), False)

            # 3. 随机动作并存储 (确保 embedding + state 拼接)
            for i in range(len(self.env.vehicles)):
                for j in range(3):
                    s_old = self.get_state([i, j])
                    emb_old = emb_all[3 * i + j]
                    
                    # 拼接：32 + 82 = 114
                    # 注意：这里假设 s_old 是 82 维。如果您的 get_state 返回不同维度，请相应调整。
                    # 重点是：emb_old (32) + s_old (82)
                    better_old = np.concatenate((emb_old, s_old), axis=0)
                    
                    # 随机动作
                    action = np.random.randint(0, self.RB_number * 3)
                    self._collect_power_and_rb(i, j, s_old, action)
            
            # 推进环境一步
            # 注意：act_for_training 在某些实现中可能需要两个参数
            self.env.act_for_training(self.action_all_with_power_training, [0,0]) 
            
            # 再次刷新特征并获取 s_new (简化版：直接存 s_old -> s_old 作为占位)
            # 在 Warmup 阶段，我们主要关注填满 Buffer，Next State 的精确性次要
            # 但为了不报错，我们构建一个合法的 better_next
            
            # 重新获取特征
            for i in range(len(self.env.vehicles)):
                for j in range(3):
                    s_next = self.get_state([i, j])
                    self.G.features[3 * i + j, :] = s_next[:60]
            
            if hasattr(self.G, "_forward_all"):
                emb_all_next = self.G._forward_all(training=False).numpy() if hasattr(self.G._forward_all(training=False), "numpy") else np.asarray(self.G._forward_all(training=False))
            else:
                emb_all_next = self.G.use_GraphSAGE(self.channel_reward, 0, list(range(N)), False)

            # 存入 Replay Buffer
            for i in range(len(self.env.vehicles)):
                for j in range(3):
                    # 为了逻辑严谨，这里应该取 s_old 和 s_next
                    # 但由于 loop 结构限制，我们近似处理
                    s_curr = self.get_state([i, j])
                    emb = emb_all[3*i+j] # 这是旧的 embedding，对应 s_old
                    state_combined = np.concatenate((emb, s_curr), axis=0)
                    
                    action = self.action_all_with_power_training[i, j, 0] + \
                             self.action_all_with_power_training[i, j, 1] * self.RB_number
                             
                    # Add to memory
                    self.memory.add(state_combined, state_combined, 0.0, int(action))

    def train(self, max_steps=1000, test_every_steps=200, test_sample=80):
        self.dqn.update_target_network()
        self.warmup() # 调用修复后的 warmup

        self.env.new_random_game()
        
        for self.step in range(1, max_steps + 1):
            is_test = (test_every_steps > 0 and self.step % test_every_steps == 0)

            if is_test:
                self.training = False
                mean_v2i, fail = self.test_environment(test_sample=test_sample, detailed=False)
                self.test_history.append((self.step, float(mean_v2i), float(fail)))
                self.v2i_curve_steps.append(self.step)
                self.v2i_curve_vals.append(float(mean_v2i))
                self.v2v_curve_vals.append(float(1.0 - fail))
                self.training = True

            # 1. 刷新节点特征
            for i in range(len(self.env.vehicles)):
                for j in range(3):
                    s = self.get_state([i, j])
                    self.G.features[3 * i + j, :] = s[:60]

            # 2. GNN 前向
            N = 3 * len(self.env.vehicles)
            t0 = time.perf_counter()
            if hasattr(self.G, "_forward_all"):
                emb_all_t = self.G._forward_all(training=False)
                emb_all = emb_all_t.numpy() if hasattr(emb_all_t, "numpy") else np.asarray(emb_all_t)
            else:
                idx_all = list(range(N))
                emb_all = self.G.use_GraphSAGE(self.channel_reward, self.step, idx_all, False)
            t1 = time.perf_counter()
            
            # 归一化
            emb_all = emb_all / (np.max(np.abs(emb_all)) + 1e-4)
            self.gnn_only_time_acc.append((t1 - t0) / max(1, N))

            # 3. 动作选择 (拼接特征)
            t2 = time.perf_counter()
            for i in range(len(self.env.vehicles)):
                for j in range(3):
                    s_old = self.get_state([i, j])
                    emb_old = emb_all[3 * i + j]
                    # 拼接
                    better_old = np.concatenate((emb_old, s_old), axis=0)
                    
                    action = self.predict(better_old, self.step)
                    self._collect_power_and_rb(i, j, s_old, action)
            t3 = time.perf_counter()
            self.full_decision_time_acc.append((t3 - t2) / max(1, N))

            # 4. 环境推进
            for i in range(len(self.env.vehicles)):
                for j in range(3):
                    _ = self.env.act_for_training(self.action_all_with_power_training, [i, j])

            # 5. DQN 更新
            if self.step >= self.warmup_steps and self.step % self.train_every_n_steps == 0:
                self.q_learning_mini_batch()
            if self.step % self.target_q_update_step == 0:
                self.dqn.update_target_network()

            used_blocks = np.unique(self.action_all_with_power_training[:, :, 0])
            self.used_blocks_history.append((self.step, len(used_blocks)))

        # End of training
        mean_v2i, fail = self.test_environment(test_sample=test_sample, detailed=True)
        self.v2i_curve_steps.append(self.step)
        self.v2i_curve_vals.append(float(mean_v2i))
        self.v2v_curve_vals.append(float(1.0 - fail))
        if hasattr(self, "_last_test_detailed") and self._last_test_detailed:
            self.last_timeseries = self._last_test_detailed.copy()
        
        # 导出结果
        self._export_results(mean_v2i, fail)


# ================= 单次运行 =================

def run_one(model_type: str, args: argparse.Namespace, out_dir: Path) -> Dict:
    tag = model_type.lower()
    prefix = f"{tag}_"

    env = HighwayTopoEnv(
        n_up=args.n_up, n_down=args.n_down, lanes_per_dir=args.lanes, spacing=args.spacing,
        base_y=args.base_y, height=args.height, topology_type=args.topo,
        leader_at_front=bool(args.leader_front), leader_lane_up=args.leader_lane_up,
        leader_lane_down=args.leader_lane_down, leader_dynamic=bool(args.leader_dynamic),
        move_speed=float(args.use_move_speed), v2i_mode=args.v2i_mode,
        bs_layout=args.bs_layout, bs_spacing=args.bs_spacing,
        bs_min_stay_steps=args.bs_min_stay, bs_handover_hyst_m=args.bs_hyst,
        seed=args.seed
    )
    env.new_random_game()
    ensure_env_difficulty(env, args.demand_amount, args.v2v_limit)

    # 注入奖励超参
    env.beta_urgency_pos = float(args.beta_urgency_pos)
    env.beta_urgency_neg = float(args.beta_urgency_neg)
    env.urgency_threshold = float(args.urgency_threshold)
    env.rb_anti_conc_alpha = float(args.rb_anti_conc_alpha)
    env.rb_hot_threshold = float(args.rb_hot_threshold)
    env.rb_softmask_alpha = float(args.rb_softmask_alpha)
    env.rb_softmask_window = int(args.rb_softmask_window)

    # 构建 GNN
    G = build_gnn(
        env,
        gnn_type=tag,
        distance_threshold=150.0,
        lr=5e-4,
        gat_train_interval=20,
        grad_clip=5.0,
        reprune_every=args.reprune_every,
        hysteresis_keep=args.hysteresis_keep,
        reprune_start_step=args.reprune_start_step,
        reg_attn_w=args.reg_attn_w,
    )

    # Agent
    agent = InstrumentedAgent(
        [],
        env,
        gnn_type=tag,
        warmup_steps=args.warmup_steps,
        epsilon_decay_steps=args.epsilon_decay_steps,
        epsilon_min=args.epsilon_min, # 支持 epsilon-min
        speed_mode=False,
        plot_dpi=args.dpi,
        beta_urgency_pos=args.beta_urgency_pos,
        beta_urgency_neg=args.beta_urgency_neg,
        urgency_threshold=args.urgency_threshold,
        rb_anti_conc_alpha=args.rb_anti_conc_alpha,
        rb_hot_threshold=args.rb_hot_threshold,
        rb_softmask_alpha=args.rb_softmask_alpha,
        rb_softmask_window=args.rb_softmask_window,
    )
    agent.G = G

    agent.train(max_steps=args.train_steps, test_every_steps=args.test_every, test_sample=args.test_sample)

    # 统计指标
    power_counts = np.zeros(3, dtype=np.int64)
    for _, pw in agent.power_log:
        if 0 <= pw < 3:
            power_counts[pw] += 1
    power_entropy = compute_entropy(power_counts)
    rb_gini = compute_gini(agent.rb_usage_counts)
    unique_rb_ratio = float(np.mean([c / agent.RB_number for _, c in agent.used_blocks_history])) if agent.used_blocks_history else 0.0
    conv_step_v2i = compute_convergence_step(agent.v2i_curve_steps, agent.v2i_curve_vals, 0.9)
    full_mean = float(np.mean(agent.full_decision_time_acc)) if agent.full_decision_time_acc else 0.0
    gnn_only_mean = float(np.mean(agent.gnn_only_time_acc)) if agent.gnn_only_time_acc else 0.0

    summary = dict(
        model=tag,
        v2i_final=float(agent.v2i_curve_vals[-1]),
        v2v_final=float(agent.v2v_curve_vals[-1]),
        v2i_conv_step=int(conv_step_v2i),
        power_entropy=float(power_entropy),
        power_counts=power_counts.tolist(),
        rb_unique_ratio=float(unique_rb_ratio),
        rb_gini=float(rb_gini),
        decision_time_full_s=full_mean,
        decision_time_gnn_only_s=gnn_only_mean,
        steps=len(agent.v2i_curve_steps),
        v2i_curve=list(zip(agent.v2i_curve_steps, agent.v2i_curve_vals)),
        v2v_curve=list(zip(agent.v2i_curve_steps, agent.v2v_curve_vals)),
        rb_usage_counts=agent.rb_usage_counts.tolist(),
        last_timeseries=agent.last_timeseries if agent.last_timeseries else None,
        agent_ref=agent,
    )
    
    # 自动保存 CSV 曲线 (方便绘图)
    csv_path_v2v = out_dir / f"{tag}_v2v_curve.csv"
    with csv_path_v2v.open("w", encoding="utf-8") as f:
        f.write("step,v2v_success\n")
        for s, v in summary["v2v_curve"]:
            f.write(f"{s},{v}\n")
            
    csv_path_v2i = out_dir / f"{tag}_v2i_curve.csv"
    with csv_path_v2i.open("w", encoding="utf-8") as f:
        f.write("step,v2i_rate\n")
        for s, v in summary["v2i_curve"]:
            f.write(f"{s},{v}\n")

    return summary


# ================= 车辆规模扫描（V2I/V2V vs 车辆数） =================

def run_sweep_vehicles(args: argparse.Namespace, out_dir: Path) -> Dict[str, Dict[str, List[float]]]:
    veh_list = parse_list_int_strict(getattr(args, "veh_list", ""))
    if not veh_list:
        return {}
    
    # 定义要对比的三个模型
    models_to_sweep = ["gat", "sage", "fc"]
    results = {m: {"veh": [], "v2i": [], "v2v": []} for m in models_to_sweep}

    print(f"\n>>> [Sweep Start] Vehicles: {veh_list} | Models: {models_to_sweep}")

    for nveh in veh_list:
        # 动态分配上下行车辆数 (各一半)
        n_up = int(np.ceil(nveh / 2))
        n_down = int(nveh - n_up)
        
        for model in models_to_sweep:
            print(f"   -> Running: Veh={nveh}, Model={model} ...")
            
            # 1. 创建环境
            env = HighwayTopoEnv(
                n_up=n_up, n_down=n_down, lanes_per_dir=args.lanes, spacing=args.spacing,
                base_y=args.base_y, height=args.height, topology_type=args.topo,
                v2i_mode=args.v2i_mode, bs_layout=args.bs_layout, bs_spacing=args.bs_spacing,
                seed=args.seed
            )
            env.new_random_game()
            ensure_env_difficulty(env, args.demand_amount, args.v2v_limit)

            # 注入奖励超参
            env.beta_urgency_pos = float(args.beta_urgency_pos)
            env.beta_urgency_neg = float(args.beta_urgency_neg)
            env.urgency_threshold = float(args.urgency_threshold)
            env.rb_anti_conc_alpha = float(args.rb_anti_conc_alpha)
            env.rb_hot_threshold = float(args.rb_hot_threshold)
            env.rb_softmask_alpha = float(args.rb_softmask_alpha)
            env.rb_softmask_window = int(args.rb_softmask_window)

            # 2. 构建 GNN (GAT/SAGE/FC)
            G = build_gnn(
                env,
                gnn_type=model,
                distance_threshold=150.0,
                lr=5e-4,
                gat_train_interval=20,
                grad_clip=5.0,
                reprune_every=args.reprune_every,
                hysteresis_keep=args.hysteresis_keep,
                reprune_start_step=args.reprune_start_step,
                reg_attn_w=args.reg_attn_w,
            )

            # 3. Agent (确保包含 epsilon_min 等修复参数)
            ag = InstrumentedAgent(
                [], env, gnn_type=model, 
                warmup_steps=args.warmup_steps,
                epsilon_decay_steps=args.epsilon_decay_steps, 
                epsilon_min=args.epsilon_min,
                speed_mode=False, 
                plot_dpi=args.dpi,
                beta_urgency_pos=args.beta_urgency_pos,
                beta_urgency_neg=args.beta_urgency_neg,
                urgency_threshold=args.urgency_threshold,
                rb_anti_conc_alpha=args.rb_anti_conc_alpha,
                rb_hot_threshold=args.rb_hot_threshold,
                rb_softmask_alpha=args.rb_softmask_alpha,
                rb_softmask_window=args.rb_softmask_window,
            )
            ag.G = G

            # 4. 训练
            # 扫描实验可以适当减少步数以节省时间，例如 1500 步
            # 如果想要更高质量，可以设为 args.train_steps
            sweep_steps = 1500 
            ag.train(max_steps=sweep_steps, test_every_steps=args.test_every, test_sample=args.test_sample)
            
            # 5. 记录最终结果
            v2i_final = ag.v2i_curve_vals[-1] if ag.v2i_curve_vals else 0.0
            v2v_final = ag.v2v_curve_vals[-1] if ag.v2v_curve_vals else 0.0
            
            results[model]["veh"].append(nveh)
            results[model]["v2i"].append(float(v2i_final))
            results[model]["v2v"].append(float(v2v_final))

    # 保存数据 CSV
    csv_path = out_dir / "sweep_vehicles.csv"
    with csv_path.open("w", encoding="utf-8") as f:
        f.write("model,n_veh,v2i_mean,v2v_success\n")
        for model in models_to_sweep:
            for n, a, b in zip(results[model]["veh"], results[model]["v2i"], results[model]["v2v"]):
                f.write(f"{model},{n},{a},{b}\n")
    
    print(f">>> Sweep complete. Data saved to {csv_path}")
    return results


# ================= 占位画图函数 (保留接口防止报错) =================

def plot_basic_comparison(gat_sum, sage_sum, out_dir):
    pass
def plot_power_vs_time(summary, out_dir, tag):
    pass
def measure_complete_vs_pruned(summary, out_dir, tag):
    pass
def plot_dynamic_timeseries(summary, out_dir, tag):
    pass


# ================= 主流程 =================

def main():
    ap = argparse.ArgumentParser(description="Compare GAT vs GraphSAGE vs FC.")
    ap.add_argument("--n-up", type=int, default=12)
    ap.add_argument("--n-down", type=int, default=20)
    ap.add_argument("--lanes", type=int, default=4)
    ap.add_argument("--spacing", type=float, default=25.0)
    ap.add_argument("--base-y", type=float, default=0.0)
    ap.add_argument("--height", type=float, default=1200.0)
    ap.add_argument("--topo", type=str, default="tree", choices=["star", "tree"])
    ap.add_argument("--leader-front", action="store_true")
    ap.add_argument("--leader-lane-up", type=int, default=None)
    ap.add_argument("--leader-lane-down", type=int, default=None)
    ap.add_argument("--leader-dynamic", action="store_true")
    ap.add_argument("--use-move-speed", type=float, default=0.0)
    ap.add_argument("--v2i-mode", type=str, default="rsu", choices=["rsu", "single"])
    ap.add_argument("--bs-layout", type=str, default="median", choices=["median", "dual-roadside"])
    ap.add_argument("--bs-spacing", type=float, default=250.0)
    ap.add_argument("--bs-min-stay", type=int, default=5)
    ap.add_argument("--bs-hyst", type=float, default=15.0)
    ap.add_argument("--train-steps", type=int, default=2400)
    ap.add_argument("--test-every", type=int, default=200)
    ap.add_argument("--test-sample", type=int, default=80)
    ap.add_argument("--warmup-steps", type=int, default=200)
    ap.add_argument("--epsilon-decay-steps", type=int, default=800)
    # === 新增参数 epsilon-min ===
    ap.add_argument("--epsilon-min", type=float, default=0.01)
    
    ap.add_argument("--demand-amount", type=float, default=130.0)
    ap.add_argument("--v2v-limit", type=float, default=0.045)
    ap.add_argument("--seed", type=int, default=123)
    ap.add_argument("--dpi", type=int, default=224)
    ap.add_argument("--out-dir", type=str, default="runs/compare_flat")
    # === 增加 FC 选项 ===
    ap.add_argument("--gnn-type", type=str, choices=["gat", "sage", "fc"], default="gat")
    
    ap.add_argument("--reprune-every", type=int, default=300)
    ap.add_argument("--hysteresis-keep", type=float, default=0.5)
    ap.add_argument("--reprune-start-step", type=int, default=600)
    ap.add_argument("--reg-attn-w", type=float, default=1e-3)
    ap.add_argument("--beta-urgency-pos", type=float, default=0.018)
    ap.add_argument("--beta-urgency-neg", type=float, default=0.025)
    ap.add_argument("--urgency-threshold", type=float, default=0.25)
    ap.add_argument("--rb-anti-conc-alpha", type=float, default=0.012)
    ap.add_argument("--rb-hot-threshold", type=float, default=0.22)
    ap.add_argument("--rb-softmask-alpha", type=float, default=0.15)
    ap.add_argument("--rb-softmask-window", type=int, default=50)
    # === 扫描实验参数 ===
    ap.add_argument("--veh-list", type=str, default="")
    ap.add_argument("--seeds", type=str, default="")

    args = ap.parse_args()
    np.random.seed(args.seed)
    out_dir = Path(args.out_dir); out_dir.mkdir(parents=True, exist_ok=True)

    combo_summary = {
        "settings": vars(args)
    }

    # === 模式选择逻辑 ===
    
    # 1. 如果指定了 veh-list，优先运行车辆数扫描实验
    if getattr(args, "veh_list", ""):
        print(">>> Mode: Vehicle Density Sweep")
        sweep_results = run_sweep_vehicles(args, out_dir)
        # 结果已保存到 CSV，此处可选是否存入 summary json
        combo_summary["sweep"] = sweep_results
        
    # 2. 如果指定了 fc，只运行 FC 基线
    elif args.gnn_type == "fc":
        print(">>> Mode: FC Baseline Only")
        fc_sum = run_one("fc", args, out_dir)
        s_clean = {k: v for k, v in fc_sum.items() if k != "agent_ref"}
        combo_summary["fc"] = s_clean

    # 3. 默认模式：运行 GAT vs GraphSAGE 对比
    else:
        print(">>> Mode: GAT vs GraphSAGE Comparison")
        gat_sum = run_one("gat", args, out_dir)
        sage_sum = run_one("sage", args, out_dir)
        combo_summary["gat"] = {k: v for k, v in gat_sum.items() if k != "agent_ref"}
        combo_summary["graphsage"] = {k: v for k, v in sage_sum.items() if k != "agent_ref"}
        
        # 只有在对比模式下才调用画图
        plot_basic_comparison(gat_sum, sage_sum, out_dir)
        plot_power_vs_time(gat_sum, out_dir, "gat")
        plot_power_vs_time(sage_sum, out_dir, "graphsage")
        measure_complete_vs_pruned(gat_sum, out_dir, "gat")
        measure_complete_vs_pruned(sage_sum, out_dir, "graphsage")
        plot_dynamic_timeseries(gat_sum, out_dir, "gat")
        plot_dynamic_timeseries(sage_sum, out_dir, "graphsage")

    # 保存 Summary
    with (out_dir / "comparison_summary.json").open("w", encoding="utf-8") as f:
        json.dump(combo_summary, f, indent=2, ensure_ascii=False)

    print("[OK] Run complete.")
    print("Results saved to:", out_dir.resolve())

if __name__ == "__main__":
    main()