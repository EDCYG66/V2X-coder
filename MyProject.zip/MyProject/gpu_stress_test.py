import tensorflow as tf
import time

# 确保能看到 GPU
gpus = tf.config.list_physical_devices('GPU')
print(f"Detected GPUs: {gpus}")

if not gpus:
    print("❌ No GPU found!")
    exit()

# 造两个巨大的矩阵 (15000 x 15000)，大约占显存，并强制计算
print("🚀 Starting GPU stress test (Matrix Multiplication)...")
print("Watch nvidia-smi now! You should see usage spike.")

# 循环计算，确保持续占用
with tf.device('/GPU:0'):
    a = tf.random.normal([15000, 15000])
    b = tf.random.normal([15000, 15000])
    
    for i in range(10):
        start = time.time()
        c = tf.matmul(a, b)
        # 强制同步执行，确保存储计算结果
        _ = c.numpy() 
        print(f"Step {i+1}: Matmul took {time.time() - start:.4f}s")

print("✅ Test done.")