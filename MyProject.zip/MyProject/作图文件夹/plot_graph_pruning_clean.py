import matplotlib.pyplot as plt
import numpy as np

# ================= 模拟数据 (与之前一致) =================
vehicles = np.array([10, 20, 30, 40, 50])

# 1. 稀疏图 (您的算法): 线性增长 O(N*K)
time_sparse = np.array([2.1, 2.5, 3.2, 4.1, 5.2]) 

# 2. 完全图 (对比): 平方增长 O(N^2)
time_complete = np.array([2.5, 4.8, 9.5, 18.2, 32.5])

# ================= 绘图 =================
plt.style.use('seaborn-v0_8-whitegrid')
plt.figure(figsize=(8, 6))

# 绘制两条线
plt.plot(vehicles, time_complete, 's--', color='gray', linewidth=2, markersize=8, label='Complete Graph (Full Mesh)')
plt.plot(vehicles, time_sparse, 'o-', color='#d62728', linewidth=3, markersize=9, label='Pruned Graph (Ours)')

# 图表装饰
plt.xlabel('Number of Vehicles', fontsize=12, fontweight='bold')
plt.ylabel('Inference Latency (ms)', fontsize=12, fontweight='bold')
plt.title('Computation Cost Analysis: Pruned vs. Complete Graph', fontsize=14, pad=15)

plt.legend(fontsize=12, frameon=True, shadow=True)
plt.grid(True, linestyle='--', alpha=0.6)
plt.xticks(vehicles) # 设置X轴刻度
plt.ylim(0, 35)      # 设置Y轴范围，使画面更有余地

# --- 关键修改：删除了这里的 plt.annotate 代码块 ---

plt.tight_layout()
plt.savefig('graph_pruning_comparison_clean.png', dpi=300)
print("已生成无标注对比图: graph_pruning_comparison_clean.png")
plt.show()